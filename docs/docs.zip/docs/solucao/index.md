---
sidebar_position: 1
slug: /solucao
title: Solução
custom_edit_url: null
---

# Solução

Bem-vindo à documentação do projeto **Grupo 03 — Turma 16**.

Este espaço reúne toda a documentação técnica e de produto desenvolvida ao longo das sprints do módulo.

## Sobre o Projeto

Descreva aqui o objetivo geral do projeto, o problema que está sendo resolvido e a solução proposta pelo grupo.

## Estrutura da Documentação

A documentação está organizada por sprint:

| Sprint | Período | Status |
|--------|---------|--------|
| [Sprint 1](../sprint-1/index.md) | — | — |
| [Sprint 2](../sprint-2/index.md) | — | — |
| [Sprint 3](../sprint-3/index.md) | — | — |
| [Sprint 4](../sprint-4/index.md) | — | — |
| [Sprint 5](../sprint-5/index.md) | — | — |

## Integrantes

Liste aqui os integrantes do grupo.
