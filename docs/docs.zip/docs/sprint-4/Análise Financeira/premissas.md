---
sidebar_position: 1
title: Premissas
---

# Premissas da Análise Financeira

## Objetivo

&emsp;Esta análise financeira tem como objetivo estimar a viabilidade econômica da implementação em produção da solução de recuperação de veículos roubados e furtados utilizando drones e visão computacional desenvolvida para a Pier.

&emsp;Como o projeto atual consiste em uma prova de conceito (PoC), algumas informações operacionais não estão disponíveis. Dessa forma, foram utilizadas premissas baseadas em pesquisas de mercado, documentação pública e estimativas da equipe.

## Premissas Gerais

### Escopo considerado

&emsp;A análise considera um cenário de implantação operacional da solução, incluindo:

- Aquisição de drones para monitoramento
- Infraestrutura computacional para processamento das imagens
- Equipe técnica para manutenção e evolução da solução
- Integração com sistemas internos da Pier
- Operação contínua do sistema

&emsp;Não são considerados:

- Custos regulatórios junto à ANAC
- Custos jurídicos
- Expansão nacional da operação
- Custos de desenvolvimento da prova de conceito acadêmica

#### Horizonte de análise

Será considerado um horizonte de operação de **5 anos**. Justificativa:

- Equipamentos como drones normalmente possuem vida útil entre 3 e 5 anos
- Permite avaliar retorno sobre investimento de médio prazo